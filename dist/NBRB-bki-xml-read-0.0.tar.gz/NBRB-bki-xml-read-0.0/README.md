# NBRB_bki_xml_read
Collection of tools for reading bki.xml files provided by National Bank of the Republic of Belarus. Find out more on https://www.nbrb.by/today/creditregistry/instructions.
